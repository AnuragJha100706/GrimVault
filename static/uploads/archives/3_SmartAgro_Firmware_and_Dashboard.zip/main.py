# SmartAgro
print('System initialized successfully.')
